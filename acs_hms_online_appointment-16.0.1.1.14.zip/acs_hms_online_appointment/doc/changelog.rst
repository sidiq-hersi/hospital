`1.1.14                                                       [11/10/2023]`
***************************************************************************
- Fix issue of payment link when sale is installed it was causing issue.

`1.1.13                                                       [12/08/2023]`
***************************************************************************
- Add option to allow booking appointment of family memeber from website. 

`1.1.12                                                       [28/07/2023]`
***************************************************************************
- On payment confirmation only show appointment confirmation details.
- Add option to pay appointment form appointment view.

`1.1.11                                                       [14/07/2023]`
***************************************************************************
- Added appointment_ids field in slot calendar view.

`1.1.10                                                        [12/05/2023]`
***************************************************************************
- Improved code for update physician data from user profile.
- Improved code for appointment Configuration menu apply groups.

`1.0.9                                                        [18/04/2023]`
***************************************************************************
- Show website related dr and departnets.

`1.0.8                                                        [16/04/2023]`
***************************************************************************
- Alow dr to manage own scheduling.

`1.0.7                                                        [22/03/2023]`
***************************************************************************
- Improved code for making appointment booking view mobile responsive.

`1.0.6                                                        [14/12/2022]`
***************************************************************************
- Do not show dates which are not available.

`1.0.5                                                        [01/12/2022]`
***************************************************************************
- Improved code for checking availability of slot on online booking.

`1.0.4                                                        [19/11/2022]`
***************************************************************************
Imoroved code for Views and allow to book 0 fee appointments also.

`1.0.3                                                        [29/10/2022]`
***************************************************************************
Added option for allowing user to book video call from booking screen 
If videocall option is selected create and send link.

`1.0.2                                                        [22/10/2022]`
***************************************************************************
Improved code for showing patient applicable price on website also.

`1.0.1                                                        [12/10/2022]`
***************************************************************************
- Launched Module for v16