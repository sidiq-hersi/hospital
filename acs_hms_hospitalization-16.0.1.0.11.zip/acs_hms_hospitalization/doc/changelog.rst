`1.0.11                                                       [04/10/2023]`
***************************************************************************
- Improved code for precription inv data.

`1.0.10                                                       [18/09/2023]`
***************************************************************************
- Improved barcode printing for report.

`1.0.9                                                       [02/08/2023]`
***************************************************************************
- Improved code for set hospital invoice type in invoice.

`1.0.8                                                        [20/06/2023]`
***************************************************************************
- Update code for create invoice pass product UOM.

`1.0.7                                                        [19/05/2023]`
***************************************************************************
- Added code for status widget on status in list view.

`1.0.6                                                        [31/03/2023]`
***************************************************************************
- Improved code for physican viw to avoid error.
- Give access of hospitalization by default to admin on installation.

`1.0.5                                                        [15/03/2023]`
***************************************************************************
- Improved code for hospitalization count.

`1.0.4                                                        [07/03/2023]`
***************************************************************************
- Added demo data for ward and bed.

`1.0.3                                                        [14/11/2022]`
***************************************************************************
- Added new button create evaluation.

`1.0.2                                                        [10/11/2022]`
***************************************************************************
- Improved access roles:
1> Hospitalization User: can create and seee hospitalizations
2> Executive: can manage all related operations.
3> Manager can delete and manage configurations.

`1.0.1                                                        [12/10/2022]`
***************************************************************************
- Launched Module for v16