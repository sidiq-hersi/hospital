`1.0.3                                                        [29/07/2023]`
***************************************************************************
- Remove name_get method and use _compute_display_name

`1.0.2                                                        [11/07/2023]`
***************************************************************************
- Added new field in attachment user_ids and write record rule for that.

`1.0.1                                                        [09/10/2022]`
***************************************************************************
- Launched Module for v16
- Moved code from acs_hms_document module to acs_document_base to avoid 
code duplication between document and hms_document modules