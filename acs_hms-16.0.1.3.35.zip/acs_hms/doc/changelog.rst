`1.3.35                                                        [04/10/2023]`
***************************************************************************
- Improved code for Medical Advice report.
- Uppdate code for appointment calendar view.  

`1.3.34                                                        [22/09/2023]`
***************************************************************************
- Add disease histoy from appointment also.

`1.3.33                                                        [18/09/2023]`
***************************************************************************
- Improved barcode printing for card.

`1.3.32                                                        [16/08/2023]`
***************************************************************************
- Added new user group allow updating done appointment.
- Added new button in appointmeent called reopen.

`1.3.31                                                        [02/08/2023]`
***************************************************************************
- Improved code for set hospital invoice type in invoice.

`1.3.30                                                        [29/07/2023]`
***************************************************************************
- Remove name_get method and use _compute_display_name

`1.3.29                                                        [15/07/2023]`
***************************************************************************
- Add Appointment Date field.

`1.3.28                                                        [25/06/2023]`
***************************************************************************
- Add option to create and link runningn treatment on appointment.

`1.3.27                                                        [20/06/2023]`
***************************************************************************
- Update code for create invoice pass product UOM.

`1.3.26                                                        [09/06/2023]`
***************************************************************************
- Added Smart button to show patients of dr.

`1.3.25                                                        [08/06/2023]`
***************************************************************************
- Added new report for medicine label.

`1.3.24                                                        [06/06/2023]`
***************************************************************************
- Improved code for pricelist price in procedure invoice from appointment.

`1.3.23                                                        [28/05/2023]`
***************************************************************************
- When dr create Appointment by default set own physician.

`1.3.22                                                        [27/05/2023]`
***************************************************************************
- Added chnages to create common invocie from appointment with linked
surgery, lab, radiology and prescription invocie also.

`1.3.21                                                        [27/05/2023]`
***************************************************************************
- Improved code to avoid error on department view and domain.

`1.3.20                                                        [19/05/2023]`
***************************************************************************
- Added code for status widget on status in list view.

`1.3.19                                                       [12/05/2023]`
***************************************************************************
- Improved code appointment view.

`1.3.18                                                       [12/05/2023]`
***************************************************************************
- Improved code for update physician data from user profile.
- Improved code for appointment Configuration menu apply groups.

`1.2.17                                                       [03/04/2023]`
***************************************************************************
- Improved code for prescription and appointment UI.
- Allow to configure on medicie if substition is alloed or not 
for default value.
- Improved Label of fields.

`1.2.16                                                       [28/04/2023]`
***************************************************************************
- Improved code for asinee field from patient to partner.
- Show own contacts to reception users also.

`1.0.15                                                       [31/03/2023]`
***************************************************************************
- Added Assignee in the patient form and added rule to see only the own
patient and added a group to see all patients too.

`1.0.14                                                       [31/03/2023]`
***************************************************************************
- Give all record access to admin users.

`1.0.13                                                       [28/03/2023]`
***************************************************************************
- Added record rules for physician to see his own appointments, treatments
and prescriptions.

`1.0.12                                                       [28/03/2023]`
***************************************************************************
- Fix the bug of no_invoice on appointment confirm.


`1.0.11                                                       [22/03/2023]`
***************************************************************************
- Consume material when marking prcedure as done.
- Add consumed materials in combined invoice of procedure also.

`1.0.10                                                       [22/03/2023]`
***************************************************************************
- Allow to confirm appointment with advance payment and exeption.

`1.0.9                                                       [20/03/2023]`
***************************************************************************
- Added option to add assigned nurse in appointment and made those appoint-
ments visible to that nurse.

`1.0.8                                                       [09/03/2023]`
***************************************************************************
- Improved code for name get method in diseases.

`1.0.7                                                       [10/02/2023]`
***************************************************************************
- Fixed error in adding consumable lines in patient procedure from treatment

`1.0.6                                                       [07/02/2023]`
***************************************************************************
- Improved code to set priority in disease.

`1.0.5                                                       [02/02/2023]`
***************************************************************************
- Improved code for linking the physician to commission partner on invoice

`1.0.4                                                        [31/01/2023]`
***************************************************************************
- For folloup service calclation avoid calculating draft and cancelled 
appointments.

`1.0.3                                                        [18/11/2022]`
***************************************************************************
- Improved code for planning compute logic.

`1.0.2                                                        [14/11/2022]`
***************************************************************************
- Added new field refer reason and refered from reason in appointment.

`1.0.1                                                        [20/10/2022]`
***************************************************************************
- Migrated Module for v16 (09/10/2022)
#New features
- Add option to set diff procedure locations
- Added option to set default appointment duration in configuration.