`1.0.6                                                        [26/10/2023]`
***************************************************************************
- Improved code for taking unit based price in prescription line.

`1.0.5                                                        [25/10/2023]`
***************************************************************************
- Improved code for create invocie from rpescription data.

`1.0.4                                                        [20/06/2023]`
***************************************************************************
- Update code for create invoice pass product UOM.

`1.0.3                                                        [27/05/2023]`
***************************************************************************
- Added changes to create common invoice from appointment

`1.0.2                                                       [02/02/2023]`
***************************************************************************
- Improved code for linking the physician to commission partner on invoice

`1.0.1                                                        [14/10/2022]`
***************************************************************************
- Launched Module for v16