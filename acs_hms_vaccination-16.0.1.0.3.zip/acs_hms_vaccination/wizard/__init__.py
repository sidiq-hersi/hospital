# -*- encoding: utf-8 -*-

from . import create_vaccination
