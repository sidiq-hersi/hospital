# -*- encoding: utf-8 -*-

from . import facility_management

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: