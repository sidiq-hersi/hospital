# -*- coding: utf-8 -*-

from odoo import api, fields, models

