# -*- encoding: utf-8 -*-

from . import hms_base

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
