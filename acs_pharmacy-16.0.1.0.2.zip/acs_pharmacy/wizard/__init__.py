# -*- encoding: utf-8 -*-

from . import stock_wizard
from . import wiz_lock_lot
from . import wiz_medicine_expiry

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: