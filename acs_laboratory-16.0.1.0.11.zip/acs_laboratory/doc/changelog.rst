`1.0.11                                                        [18/09/2023]`
***************************************************************************
- Improved barcode printing for report.

`1.0.10                                                       [14/08/2023]`
***************************************************************************
- Fixed bug when create lab bill.

`1.0.9                                                        [29/07/2023]`
***************************************************************************
- Remove name_get method and use _compute_display_name

`1.0.8                                                        [07/06/2023]`
***************************************************************************
- Add  utton to update price from button based on pricelist.

`1.0.7                                                        [27/05/2023]`
***************************************************************************
- Added changes to create common invoice from appointment

`1.0.6                                                        [19/05/2023]`
***************************************************************************
- Added code for status widget on status in list view.
- Improved code for state field in website.

`1.0.5                                                        [13/03/2023]`
***************************************************************************
- Added code for Lab Prescription Table.

`1.0.4                                                        [02/02/2023]`
***************************************************************************
- Improved code for linking the physician to commission partner on invoice

`1.0.3                                                        [24/12/2022]`
***************************************************************************
- Show invocie count on smart button.

`1.0.2                                                        [29/10/2022]`
***************************************************************************
- Allow users to set default collection center on profile.

`1.0.1                                                        [09/10/2022]`
***************************************************************************
- Launched Module for v16