# -*- coding: utf-8 -*-

from . import hms_base
from . import company
from . import patient
from . import evaluation
from . import product_kit
from . import physician
from . import appointment
from . import diseases
from . import medicament
from . import prescription
from . import procedure
from . import treatment
from . import resource
from . import account
from . import res_config_settings
from . import digest
from . import res_users

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: