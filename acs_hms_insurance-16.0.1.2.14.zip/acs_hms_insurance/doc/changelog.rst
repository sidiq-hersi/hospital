`1.2.14                                                       [29/07/2023]`
***************************************************************************
- Remove name_get method and use _compute_display_name

`1.2.13                                                        [06/07/2023]`
***************************************************************************
- Added code for new filter inactive insurance.

`1.2.12                                                        [06/06/2023]`
***************************************************************************
- Improved code invoice Spliting patient share with 100% invoice

`1.2.11                                                        [06/06/2023]`
***************************************************************************
- Improved code invoice Spliting

`1.2.10                                                        [31/05/2023]`
***************************************************************************
- Improved code for insuralce policy view 
- Improved code for patient share rules.
- Access Rights improvements

`1.0.9                                                        [29/05/2023]`
***************************************************************************
- Add option to set patietn share product in insurance company.

`1.0.8                                                        [28/05/2023]`
***************************************************************************
- Added support for invoice split with new line.

`1.0.7                                                        [17/05/2023]`
***************************************************************************
- Improved code for insurance data on list and search of appointment and
 prescription

`1.0.6                                                        [16/05/2023]`
***************************************************************************
- Improved Insurace policy form view.

`1.0.5                                                        [15/05/2022]`
***************************************************************************
- Improved flow for adding patient insurace data on insurace company invocie.

`1.0.4                                                        [12/05/2022]`
***************************************************************************
- Improved flow for adding patient insurace data on insurace company invocie.

`1.0.3                                                        [03/12/2022]`
***************************************************************************
- Improved code for auto archiving policy.

`1.0.2                                                        [11/11/2022]`
***************************************************************************
- Packge feature is moved to surgey for more genric use.

`1.0.1                                                        [13/10/2022]`
***************************************************************************
- Launched Module for v16